
#include "app.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void *probe_packet_copy(void *dst,const void *src,size_t n){
 printf("COPY packet %zu\n",n);fflush(stdout);
 if(n>COMMAND_CAPACITY){puts("FIRST_UNSAFE_COPY packet_decode");fflush(stdout);_Exit(10);}
 return memcpy(dst,src,n);
}
void *probe_app_copy(void *dst,const void *src,size_t n){
 printf("COPY dispatch %zu\n",n);fflush(stdout);
 if(n>COMMAND_CAPACITY){puts("FIRST_UNSAFE_COPY app_dispatch");fflush(stdout);_Exit(20);}
 return memcpy(dst,src,n);
}
int main(int argc,char **argv){
 App app={0};unsigned n=(unsigned)strtoul(argv[1],0,10);
 if(argc>2){Command command={0};command.opcode=2;command.sequence=1;command.length=n;
  int accepted=queue_push(&app.commands,&command);printf("DIRECT_QUEUE %d\n",accepted);
  if(accepted)app_dispatch(&app);return 0;}
 unsigned char *frame=calloc(n+8u,1);if(!frame)return 3;
 write_be16(frame,2);write_be16(frame+2,1);write_be16(frame+4,n);
 memset(frame+6,'A',n);write_be16(frame+n+6,crc16(frame,n+6));
 int accepted=app_ingest(&app,frame,n+8u);printf("INGEST %d QUEUE %u\n",accepted,app.commands.count);
 if(accepted)app_dispatch(&app);free(frame);return 0;
}
