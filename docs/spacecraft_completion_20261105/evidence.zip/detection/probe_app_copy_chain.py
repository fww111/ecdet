"""Observe real command ingress; stop at the first unsafe copy, never execute UB."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent/'app_copy_chain'
WORKSPACE=Path(__file__).resolve().parents[2]
REPO=WORKSPACE/'ecdet'
OUT.mkdir(exist_ok=True)
HARNESS=r'''
#include "app.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void *probe_packet_copy(void *dst,const void *src,size_t n){
 printf("COPY packet %zu\n",n);fflush(stdout);
 if(n>COMMAND_CAPACITY){puts("FIRST_UNSAFE_COPY packet_decode");fflush(stdout);_Exit(10);}
 return memcpy(dst,src,n);
}
void *probe_app_copy(void *dst,const void *src,size_t n){
 printf("COPY dispatch %zu\n",n);fflush(stdout);
 if(n>COMMAND_CAPACITY){puts("FIRST_UNSAFE_COPY app_dispatch");fflush(stdout);_Exit(20);}
 return memcpy(dst,src,n);
}
int main(int argc,char **argv){
 App app={0};unsigned n=(unsigned)strtoul(argv[1],0,10);
 if(argc>2){Command command={0};command.opcode=2;command.sequence=1;command.length=n;
  int accepted=queue_push(&app.commands,&command);printf("DIRECT_QUEUE %d\n",accepted);
  if(accepted)app_dispatch(&app);return 0;}
 unsigned char *frame=calloc(n+8u,1);if(!frame)return 3;
 write_be16(frame,2);write_be16(frame+2,1);write_be16(frame+4,n);
 memset(frame+6,'A',n);write_be16(frame+n+6,crc16(frame,n+6));
 int accepted=app_ingest(&app,frame,n+8u);printf("INGEST %d QUEUE %u\n",accepted,app.commands.count);
 if(accepted)app_dispatch(&app);free(frame);return 0;
}
'''

def main():
    names=['01_earth_observer','02_deep_space_probe','03_lunar_lander','04_orbital_servicer']
    receipts=[];cpp=[];callers=[]
    for name in names:
        for variant in ['original','reference']:
            root=(REPO/'examples/spacecraft_local'/name) if variant=='original' else (WORKSPACE/'spacecraft_samples_20261104/controls'/(name+'_reference'))
            dest=OUT/name/variant;dest.mkdir(parents=True,exist_ok=True)
            inputs={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [*root.glob('src/*.c'),*root.glob('include/*.h')]}
            # Compile complete original sources. Only packet.c/app.c copies
            # route memcpy to observers which stop BEFORE invalid memory access.
            files=[]
            for p in root.glob('src/*.c'):
                if p.name=='main.c':continue
                if p.name in ('packet.c','app.c'):
                    name_fn='probe_packet_copy' if p.name=='packet.c' else 'probe_app_copy'
                    copy=dest/p.name
                    prefix='#include <stddef.h>\n#include <string.h>\nvoid *'+name_fn+'(void *,const void *,size_t);\n#define memcpy '+name_fn+'\n'
                    copy.write_text(prefix+p.read_text(encoding='utf-8'),encoding='utf-8');files.append(copy)
                else:files.append(p)
                for line,text in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
                    if 'queue_push(' in text:callers.append(dict(project=name,variant=variant,file=p.relative_to(root).as_posix(),line=line,code=text.strip()))
            harness=dest/'harness.c';harness.write_text(HARNESS,encoding='utf-8');binary=dest/'probe.exe'
            command=[r'C:\mingw64\bin\gcc.exe','-std=c11','-O0','-I'+str(root/'include'),str(harness),*map(str,files),'-lm','-o',str(binary)]
            build=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace')
            (dest/'compile.log').write_text(build.stdout+build.stderr,encoding='utf-8');assert build.returncode==0,(name,variant)
            for length in [0,64,65,79,80,192,193]:
                run=subprocess.run([str(binary),str(length)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=10)
                expected=10 if variant=='original' and 64<length<=192 else 0
                assert run.returncode==expected,(name,variant,length,run.returncode,run.stdout)
                if variant=='reference' and length>64:assert 'INGEST 0 QUEUE 0' in run.stdout and 'COPY dispatch' not in run.stdout
                receipts.append(dict(project=name,variant=variant,mode='real_ingress',length=length,returncode=run.returncode,stdout=run.stdout,expected_match=True))
            if variant=='reference':
                run=subprocess.run([str(binary),'65','direct'],capture_output=True,text=True,encoding='utf-8',timeout=10)
                assert run.returncode==20 and 'DIRECT_QUEUE 1' in run.stdout
                receipts.append(dict(project=name,variant=variant,mode='out_of_program_direct_queue_injection',length=65,returncode=run.returncode,stdout=run.stdout,expected_match=True))
                command=[str(Path.home()/'AppData/Local/Programs/CppcheckPortable/cppcheck.exe'),'--xml','--xml-version=2','--enable=warning,style,portability,performance','--inline-suppr','-I'+str(root/'include'),*map(str,root.glob('src/*.c'))]
                result=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
                (dest/'cppcheck.xml').write_text(result.stderr,encoding='utf-8')
                xml=ET.fromstring(result.stderr[result.stderr.index('<?xml'):]);matches=[]
                for error in xml.findall('.//error'):
                    locations=error.findall('location')
                    if error.get('id')=='bufferAccessOutOfBounds' and any(Path(l.get('file','')).name=='app.c' and l.get('line')=='104' for l in locations):matches.append(dict(error.attrib))
                cpp.append(dict(project=name,reference_app104_reported=bool(matches),diagnostics=matches,returncode=result.returncode))
            assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in inputs.items())
            (dest/'sources.json').write_text(json.dumps(inputs,indent=2),encoding='utf-8')
    conclusion=dict(independent_new_defects=0,classification='DOWNSTREAM_OF_B01_WITH_CONDITIONAL_API_PRECONDITION',
        reason='Within each complete program, link_receive is the only queue_push caller and requires packet_decode success. Fixing B01 establishes length<=64 before queue insertion. app.c:104 is a downstream boundary site, not a new independent root under this ingress invariant. Direct external queue injection can violate the invariant but is absent from the shipped program call graph.',
        instrumentation='Original source copies use observed memcpy wrappers; stop before the first unsafe copy. No uninstrumented undefined-behavior execution is counted as proof.',
        probe_scope='Calls real app_ingest/app_dispatch functions from a bounded harness with a zero-initialized App. Does not run the original main or scheduler. Four direct queue injections intentionally violate the ingress precondition and are not shipped-program paths.',
        counts=dict(total_probes=60,real_ingress_function_probes=56,synthetic_direct_queue_probes=4,
            valid_ingress_and_dispatch=16,rejected_before_queue_insertion=24,
            stopped_before_B01_packet_overflow=16,stopped_before_synthetic_dispatch_overread=4),
        all_original_source_hashes_unchanged=True,
        runs=receipts,reference_cppcheck=cpp,queue_push_definitions_and_calls=callers)
    (OUT/'conclusion.json').write_text(json.dumps(conclusion,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(dict(runs=len(receipts),all_expected=True,new_independent_defects=0,reference_cppcheck=cpp),ensure_ascii=False))

if __name__=='__main__':main()
