# 航天器嵌入式软件测试证据包

先阅读根目录的完整测试报告。该副本将已收录的本地绝对链接转换为包内相对链接；`original_local_report/`保留原始报告字节。

## 目录

- `scans_ctu_final/`：8个缺陷工程的SARIF、HTML、源码哈希、CodeChecker和子分析回执。
- `reference_scans_final/`：5个参考工程的扫描结果及原始/参考缺陷对照。
- `controls/`：上述5个参考工程的实际源码快照及准备回执。
- `business_pairs/`、`constraints/`、`detection/`：业务契约、约束分析及新增实例检测证据。
- `cppcheck/`、`llm/`：独立引擎与真实模型测试记录；运行失败保留失败状态。
- `tooling/`：安装来源、版本、SHA256、环境配置和工具正反例。安装程序和二进制需按记录另行获取。
- `comparison/`：队友原报告及此前在本机的对照审查，原有数字保留为历史记录。
- `replay/`：完整共享样例、业务契约、本轮修改源码、新增实现、测试、脚本和CI工作流。
- `recovery/`：相对基线的完整已跟踪文件补丁及源码快照哈希。
- `archive_manifest.json`：归档文件的SHA-256与来源范围；清单自身由整个ZIP的SHA-256覆盖。

## 恢复本地实现

在独立目录克隆仓库并检出基线`cf38ac9405818947fa39d4189178192d9421c44f`。保持该目录干净，先检查再应用`recovery/tracked.patch`：

```powershell
git apply --check "<证据包目录>/recovery/tracked.patch"
git apply "<证据包目录>/recovery/tracked.patch"
```

随后把`replay/`的内容按相同相对路径复制到该独立仓库。它包含新增文件和修改后文件的原始快照。根据`recovery/source_snapshot.json`逐项核对文件SHA256；`tracked.patch`保留已跟踪文件的完整差异。

依赖信息见`replay/pyproject.toml`、`tooling/environment.json`与`tooling/installation_validation.json`。这些路径记录原机器环境，换机后按实际安装路径调整。恢复后按报告和`replay/examples/spacecraft_suite/README.md`中的命令运行测试。

## 制作与证据含义

此包由`package_evidence.py`生成。在本次原工作区制作时，先运行`python package_evidence.py --check-only`检查输入，再在最终报告和完整测试回执齐备后运行`python package_evidence.py`。脚本检查完整测试、13次扫描回执和44项根因门禁，并写入ZIP成员哈希及归档SHA-256。

业务契约对照中的`FAIL`表示刻意缺陷按预期被触发。`TIMEOUT`、`BOUND_EXHAUSTED`、`UNSUPPORTED`、`NO_QUERIES`分别记录资源或模型限制，44项根因检出与各子分析器的完整性分别统计。
