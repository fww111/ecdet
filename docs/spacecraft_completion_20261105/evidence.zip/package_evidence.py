"""Create an auditable evidence ZIP; --check-only never creates an archive.

The archive restores the local change on cf38ac9 via a tracked-file patch plus
explicit source overlays. All members use relative paths and a text allowlist.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import unquote

O = Path(__file__).resolve().parent
R = O.parent / 'ecdet'
# Full known baseline; kept literal so a changed branch cannot change provenance.
BASE = 'cf38ac9405818947fa39d4189178192d9421c44f'
REPORT = '航天器嵌入式软件_完整测试报告_20261105.md'
TEAM_REPORT = Path('D:/xwechat_files/wxid_9vp98tndv6fk22_bb41/temp/RWTemp/2026-11/2a62f39008aa8c942813d4a09ee77cb1/航天器嵌入式样例检测测试报告_20261105.md')
TEXT_SUFFIXES = {'.c', '.h', '.svd', '.json', '.csv', '.sarif', '.xml', '.txt',
                 '.md', '.py', '.yml', '.yaml', '.toml', '.log', '.html', '.patch'}
EXCLUDED_DIRS = {'.git', '.venv', '__pycache__', '.pytest_cache', 'ecdet_build',
                 'ecdet_reports', 'build', 'node_modules', 'downloads', 'cache'}
CREDENTIAL_KEYS = {'api_key', 'apikey', 'access_token', 'refresh_token', 'password',
                   'authorization', 'client_secret', 'secret_key'}
TOKEN_PATTERNS = [re.compile(r'gh[pousr]_[A-Za-z0-9]{30,}'),
                  re.compile(r'sk-(?:proj-)?[A-Za-z0-9_-]{30,}'),
                  re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
                  re.compile(r'(?i)authorization:\s*bearer\s+[A-Za-z0-9_.-]{20,}')]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=R, stderr=subprocess.PIPE)


def safe_path(name):
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or not p.parts or ':' in p.parts[0]:
        raise ValueError('Unsafe archive member: '+name)
    if any(s in EXCLUDED_DIRS for s in p.parts) or p.name.lower().startswith('.env'):
        return False
    if p.suffix.lower() not in TEXT_SUFFIXES and p.name not in {'.gitignore', '.gitattributes'}:
        return False
    return True


def check_content(name, data):
    text = data.decode('utf-8-sig')
    if any(pattern.search(text) for pattern in TOKEN_PATTERNS):
        raise ValueError('Credential-shaped content rejected in '+name)
    if name.endswith('.json'):
        def visit(value):
            if isinstance(value, dict):
                for key, item in value.items():
                    if key.lower() in CREDENTIAL_KEYS and isinstance(item, str) and item.strip():
                        if item.strip().lower() not in {'[redacted]', 'redacted', '***', 'masked'}:
                            raise ValueError('Nonempty credential field rejected in '+name)
                    visit(item)
            elif isinstance(value, list):
                for item in value: visit(item)
        visit(json.loads(text))


def collect():
    entries = {}; source_map = {}; missing = []
    def add(path, name=None, required=False):
        path = Path(path)
        if not path.is_file():
            if required: missing.append(str(path))
            return
        archive_name = name or path.relative_to(O).as_posix()
        if not safe_path(archive_name): return
        data = path.read_bytes(); check_content(archive_name, data)
        if archive_name in entries and entries[archive_name] != data:
            raise ValueError('Archive member collision: '+archive_name)
        entries[archive_name] = data
        source_map[str(path.resolve()).casefold()] = archive_name
    def tree(directory, prefix=None):
        directory = Path(directory)
        for p in directory.rglob('*'):
            if p.is_file():
                name = (prefix+'/'+p.relative_to(directory).as_posix()) if prefix else p.relative_to(O).as_posix()
                add(p, name)

    required = [REPORT, 'scan_audit.json', 'suite_independent_review.json', 'suite_review_final.xml',
        'business_pairs/pairs.json', 'full_verified/full_suite.xml', 'full_verified/receipt.json',
        'full_verified/source_hashes.json', 'tooling/installation_validation.json', 'tooling/environment.json',
        'tooling/verified_download_hashes.json', 'ctu_final_validation.json',
        'constraints/validation_summary.json', 'constraints/compiler_context_pair.json',
        'reference_scans_final/root_comparison.json', 'detection/app_copy_chain/conclusion.json',
        'scans_ctu_final/summary.json', 'reference_scans_final/summary.json',
        'work_record/final_report_review.json', 'review/rule_expectations_comparison.json']
    for name in required: add(O/name, required=True)
    for name in ['scan_suite_ctu_final.log', 'scan_suite_ctu_final_request.json', 'scan_suite_ctu_final_exit.json',
                 'reference_scans_final.log', 'constraints_final.xml', 'constraints_final.log',
                 'suite_review_final.log', 'suite_before.log', 'suite_before.xml', 'llm_availability.json',
                 'aggregate_final.py', 'compare_reference_roots.py', 'run_reference_scans.py',
                 'package_evidence.py', 'finalize_report.py', 'full_verified/full_suite.log']:
        add(O/name)
    for folder in ['review', 'work_record', 'cppcheck', 'constraints', 'detection', 'business_pairs', 'controls', 'llm/controlled', 'llm/spacecraft']:
        tree(O/folder)

    # Eight original scans plus five reference scans; require each native receipt.
    scan_groups = {'scans_ctu_final': ['aocs', 'eps', 'obdh', 'ttc', '01_earth_observer',
                    '02_deep_space_probe', '03_lunar_lander', '04_orbital_servicer'],
                   'reference_scans_final': ['eps', '01_earth_observer', '02_deep_space_probe',
                    '03_lunar_lander', '04_orbital_servicer']}
    for group, projects in scan_groups.items():
        for project in projects:
            folder = O/group/project
            for rel in ['receipt.json', 'scan.log', 'results.sarif', 'report.html', 'codechecker/latest.json']:
                add(folder/rel, required=True)
            for rel in ['constraints.json', 'esbmc/receipt.json', 'esbmc/run.log', 'business-contracts/contracts.json']:
                add(folder/rel)
            tree(folder/'business-contracts')

    # Tool installation receipts and reproducible probes, never downloaded packages.
    for p in (O/'tooling').iterdir():
        if p.is_file() and p.name != 'cppcheck-install.log': add(p)
    for folder in ['tooling/probes', 'tooling/multi_tu_中文', 'tooling/multi_tu_run']:
        tree(O/folder)
    for group in ['ctu_probes', 'ctu_probes_noctu']:
        add(O/'tooling'/group/'results.json', required=True)
        for p in (O/'tooling'/group).glob('*_reports/latest.json'): add(p)
        for p in (O/'tooling'/group).glob('*_reports/runs/*/*.log'): add(p)
        for p in (O/'tooling'/group).glob('*/*.c'): add(p)

    # Snapshot all shared fixtures and exact local changes, including new workflow/tests.
    for folder in ['examples/spacecraft_suite', 'examples/spacecraft', 'examples/spacecraft_local', 'examples/business_contracts']:
        tree(R/folder, 'replay/'+folder)
    for name in ['docs/spacecraft_verification_20261105/review29.json',
                 'docs/spacecraft_verification_20261105/resolved_false_positives.json',
                 'docs/spacecraft_verification_20261105/summary.json',
                 'docs/航天样例修复与复验_20261104.md', 'docs/航天样例业务契约与告警复核_20261105.md',
                 'pyproject.toml', 'README.md', 'AGENTS.md', 'docs/LLM能力与验证约束.md']:
        add(R/name, 'replay/'+name, required=True)
    assert git('rev-parse', BASE).decode().strip() == BASE
    git('merge-base', '--is-ancestor', BASE, 'HEAD')
    tracked = [s for s in git('diff', '--name-only', '-z', BASE, '--').decode('utf-8').split('\0') if s]
    untracked = [s for s in git('ls-files', '--others', '--exclude-standard', '-z').decode('utf-8').split('\0') if s]
    for name in tracked:
        if not safe_path(name): raise ValueError('Non-source tracked change requires review: '+name)
        if (R/name).exists(): add(R/name, 'replay/'+name)
    allowed = ('ecdet/', 'tests/', 'scripts/', '.github/workflows/', 'examples/spacecraft/',
               'examples/spacecraft_local/', 'examples/spacecraft_suite/', 'examples/business_contracts/')
    for name in untracked:
        if not name.startswith(allowed): raise ValueError('Unreviewed untracked file: '+name)
        if not safe_path(name): raise ValueError('Disallowed untracked file: '+name)
        add(R/name, 'replay/'+name, required=True)
    patch = git('diff', '--binary', '--full-index', BASE, '--')
    check_content('recovery/tracked.patch', patch)
    entries['recovery/tracked.patch'] = patch
    snapshot = {name.removeprefix('replay/'): hashlib.sha256(data).hexdigest()
                for name, data in entries.items() if name.startswith('replay/')}
    recovery = dict(base_commit=BASE, checkout_head=git('rev-parse', 'HEAD').decode().strip(),
                    tracked_changes=tracked, untracked_files=untracked, source_snapshot_sha256=snapshot,
                    patch_sha256=hashlib.sha256(patch).hexdigest(), source_line_endings='Original working-copy bytes preserved')
    entries['recovery/source_snapshot.json'] = json.dumps(recovery, ensure_ascii=False, indent=2).encode('utf-8')

    add(TEAM_REPORT, 'comparison/teammate_report_20261105.md', required=True)
    comparison = O.parent/'spacecraft_report_comparison_20261105'
    for name in ['comparison_conclusions.json', 'environment.json', 'teammate_ten_locations.json', 'teammate_tests.log', 'teammate_tests.xml']:
        add(comparison/name, 'comparison/our_audit/'+name, required=True)
    # Keep local-path original and an archive-readable Markdown version.
    if REPORT in entries:
        original = entries[REPORT]
        entries['original_local_report/'+REPORT] = original
        def link(match):
            value = unquote(match[1].strip('<>'))
            if value.startswith('/') and re.match(r'/[A-Za-z]:/', value): value=value[1:]
            if not re.match(r'^[A-Za-z]:[/\\]', value): return match[0]
            normalized = str(Path(value).resolve()).casefold()
            if normalized not in source_map:
                missing.append('Report link not packaged: '+value)
                return match[0]
            return ']('+source_map[normalized]+')'
        entries[REPORT] = re.sub(r'\]\(([^)]+)\)', link, original.decode('utf-8')).encode('utf-8')
    return entries, recovery, missing


README = """# 航天器嵌入式软件测试证据包

先阅读根目录的完整测试报告。该副本将已收录的本地绝对链接转换为包内相对链接；`original_local_report/`保留原始报告字节。

## 目录

- `scans_ctu_final/`：8个缺陷工程的SARIF、HTML、源码哈希、CodeChecker和子分析回执。
- `reference_scans_final/`：5个参考工程的扫描结果及原始/参考缺陷对照。
- `controls/`：上述5个参考工程的实际源码快照及准备回执。
- `business_pairs/`、`constraints/`、`detection/`：业务契约、约束分析及新增实例检测证据。
- `cppcheck/`、`llm/`：独立引擎与真实模型测试记录；运行失败保留失败状态。
- `tooling/`：安装来源、版本、SHA256、环境配置和工具正反例。安装程序和二进制需按记录另行获取。
- `comparison/`：队友原报告及此前在本机的对照审查，原有数字保留为历史记录。
- `replay/`：完整共享样例、业务契约、本轮修改源码、新增实现、测试、脚本和CI工作流。
- `recovery/`：相对基线的完整已跟踪文件补丁及源码快照哈希。
- `archive_manifest.json`：归档文件的SHA-256与来源范围；清单自身由整个ZIP的SHA-256覆盖。

## 恢复本地实现

在独立目录克隆仓库并检出基线`cf38ac9405818947fa39d4189178192d9421c44f`。保持该目录干净，先检查再应用`recovery/tracked.patch`：

```powershell
git apply --check "<证据包目录>/recovery/tracked.patch"
git apply "<证据包目录>/recovery/tracked.patch"
```

随后把`replay/`的内容按相同相对路径复制到该独立仓库。它包含新增文件和修改后文件的原始快照。根据`recovery/source_snapshot.json`逐项核对文件SHA256；`tracked.patch`保留已跟踪文件的完整差异。

依赖信息见`replay/pyproject.toml`、`tooling/environment.json`与`tooling/installation_validation.json`。这些路径记录原机器环境，换机后按实际安装路径调整。恢复后按报告和`replay/examples/spacecraft_suite/README.md`中的命令运行测试。

## 制作与证据含义

此包由`package_evidence.py`生成。在本次原工作区制作时，先运行`python package_evidence.py --check-only`检查输入，再在最终报告和完整测试回执齐备后运行`python package_evidence.py`。脚本检查完整测试、13次扫描回执和44项根因门禁，并写入ZIP成员哈希及归档SHA-256。

业务契约对照中的`FAIL`表示刻意缺陷按预期被触发。`TIMEOUT`、`BOUND_EXHAUSTED`、`UNSUPPORTED`、`NO_QUERIES`分别记录资源或模型限制，44项根因检出与各子分析器的完整性分别统计。
"""


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
    entries,recovery,missing=collect()
    report=entries.get(REPORT,b'').decode('utf-8')
    if 'DRAFT' in report: missing.append('Final report still marked DRAFT')
    entries['README.md']=README.encode('utf-8')
    if args.check_only:
        print(json.dumps(dict(check_only=True,archive_created=False,planned_entries=len(entries),
            tracked_changes=len(recovery['tracked_changes']),untracked_files=len(recovery['untracked_files']),
            pending_required=missing),ensure_ascii=False,indent=2));return
    if missing: raise RuntimeError('Required final evidence missing: '+json.dumps(missing,ensure_ascii=False))
    import xml.etree.ElementTree as ET
    tests=list(ET.fromstring(entries['full_verified/full_suite.xml']).iter('testcase'))
    assert tests and all(t.find('failure') is None and t.find('error') is None for t in tests)
    full=json.loads(entries['full_verified/receipt.json'])
    assert full.get('returncode') == 0, full
    hashes=json.loads(entries['full_verified/source_hashes.json'])
    assert all(hashlib.sha256((R/name).read_bytes()).hexdigest()==digest for name,digest in hashes.items()), 'Tested sources changed'
    report_review=json.loads(entries['work_record/final_report_review.json'])
    assert report_review['frozen'] and report_review['manual_sentence_review']['completed'], 'Final sentence review incomplete'
    assert report_review['report_sha256']==hashlib.sha256(entries['original_local_report/'+REPORT]).hexdigest(), 'Report changed after review'
    summary=json.loads(entries['scans_ctu_final/summary.json']);assert summary['detected']==summary['total']==44
    assert len(summary['projects'])==8
    assert len(json.loads(entries['reference_scans_final/summary.json'])['projects'])==5
    native=[json.loads(data) for name,data in entries.items() if name.startswith(('scans_ctu_final/','reference_scans_final/')) and name.endswith('/codechecker/latest.json')]
    assert len(native)==13 and all(n['status']=='complete' and n['ctu'] for n in native)
    assert all(set(n['executed_analyzers'])=={'clangsa','clang-tidy','gcc','cppcheck'} for n in native)
    manifest=dict(base_commit=BASE,scope='final report, 13 scans, recovery sources and reviewed text evidence',
        members={name:dict(size=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in sorted(entries.items())})
    entries['archive_manifest.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
    for name,data in entries.items():
        assert safe_path(name),name
        check_content(name,data)
    destination=O.parent/'航天器嵌入式软件_完整测试证据_20261105.zip'
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(entries.items()): z.writestr(name,data)
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(entries)
        for name,data in entries.items(): assert z.read(name)==data,name
    receipt=dict(archive=str(destination),size=destination.stat().st_size,
                 sha256=hashlib.sha256(destination.read_bytes()).hexdigest(),entries=len(entries),base_commit=BASE)
    (O/'archive_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False))


if __name__=='__main__': main()
