"""Source review of the current Cppcheck diagnostics; no severity-based labels."""
import collections
import csv
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
REPO=OUT.parent.parent/'ecdet'
data=json.loads((OUT/'results.json').read_text(encoding='utf-8'))
manifest=json.loads((REPO/'examples/spacecraft_suite/manifest.json').read_text(encoding='utf-8'))
roots={p['name']:REPO/p['path'] for p in manifest['projects']}
D='CONFIRMED_SOURCE_DEFECT';B='VALID_RULE_NOTICE';F='CONFIRMED_FP';R='NEEDS_REVIEW';S='DOWNSTREAM_DUPLICATE_RISK'
# Explicit per-location reviews, checked against the source rather than severity.
reviews={
'aocs':[
(D,'quat声明为float[4]，attitude.c:121写索引4，合法最大索引为3。'),
(B,'attitude.c:125的循环正常结束后i为4，130处被求值的++i为5，条件恒真；这是冗余条件与副作用提示，未另计业务故障。'),
(B,'fdir.c:97的msg只在103—114的if块内使用，可缩小声明作用域；未形成独立运行缺陷。'),
(B,'fdir.c:98的record只在103—114的if块内分配、访问和释放，可缩小作用域。'),
(D,'imu.c:18声明s_calib[6]，30处写索引6，超过0—5。'),
(D,'main.c:159的frame_header容量32；162处字符串AOCS_TM_FRAME_V2_NOMINAL_ORBIT_2026连同NUL需要36字节。'),
(F,'main.c:24将g_sys_tick声明为volatile，33处ISR递增；47处保存历史值后48处必须重新读取volatile，不能把两个读数等同。告警把外部可变化值当作不变值。'),
(D,'orbit.c:77的scratch为自动存储期double，82返回其地址；函数返回后该对象生命周期结束。77和82是同一告警路径，不能计两个缺陷。'),
(D,'orbit.c:92的snapshot只有3个double，当前工具链共24字节；99复制48字节造成源越界读，dst的容量没有在本函数中给出。'),
(B,'orbit.c:54是work[0]的自赋值，work为普通局部数组；冗余操作成立，未据此推断轨道算法故障。'),
(D,'orbit.c:67无条件return，68的状态更新没有标签或其他入口，确定不可达。'),
(B,'orbit.c:41声明tmp[6]，后续没有使用；属于未使用变量提示。'),
(B,'wheel.c:86的err仅在93—99循环内赋值和读取，可缩小作用域。'),
(B,'wheel.c:87的torque仅在93—99循环内赋值和读取，可缩小作用域。'),
(D,'wheel.c:107对32位unsigned int字面量1u左移40位，移位数超过类型宽度。'),
],
'eps':[
(D,'battery.c:17声明s_soc_table[11]，33写索引11，超过0—10。'),
(B,'heater.c:73的sizeof(i++)不求值非VLA标量操作数，i不自增；代码事实是sizeof中的副作用表达式，未额外证明控制故障。'),
(D,'mppt.c:17声明s_power_samples[4]，43写索引4，超过0—3。'),
(B,'mppt.c:10定义MPPT_DUTY_MIN为0u，s_mppt.duty为无符号字段，93的下界比较恒假；保留下界检查无效提示，不把潜在下溢路径当已运行故障。'),
(D,'protection.c:24声明s_trip_table[8]，43写索引8，超过0—7。'),
(B,'protection.c:110给soc_ptr赋battery_soc地址，111只解引用读取，没有通过该指针修改对象，增加const的建议成立。'),
(D,'protection.c:88对32位1u左移33位，移位数超过类型宽度。'),
],
'obdh':[
(D,'ccsds.c:44声明frame_body[256]，71写索引256，超过0—255。'),
(D,'ccsds.c的staging为16字节数组，61固定复制32字节；packet->data容量较大不消除源越界读。'),
(B,'ccsds.c:71对frame_body的写入未被后续使用，死写提示成立；同位置另有越界告警，本条不再计为第二个缺陷。'),
(D,'crc.c:13的CRC_NIBBLE_ADD(v)展开为((v)+(v))，66传入i++后形成未排序的两次自增，行为未定义。'),
(B,'crc.c:58的vector初始化后仅被crc16_update读取，可声明const；不是内存破坏。'),
(F,'main.c:23将g_obdh_tick声明为volatile，82处ISR递增；40处的start是快照，41处重新读取节拍，不能证明两次值相同。'),
(D,'payload.c:114释放s_payload_builtin静态数组地址；该地址不是动态分配返回值，free不合法。'),
(D,'payload.c:68—69分别声明cache[32]与source[16]，96复制64字节同时越界读和写；相同规则、文件、行合并为一个复制根因。'),
(D,'payload.c:68—69分别声明cache[32]与source[16]，96复制64字节同时越界读和写；相同规则、文件、行合并为一个复制根因。'),
(B,'ringbuf.c:84的sizeof(depth++)对标量不执行自增；属于易误解的sizeof表达式，未把它等同于实际深度变化。'),
(D,'ringbuf.c:78对32位1u左移36位，移位数超过类型宽度。'),
(D,'tc.c:63的cmd_name[16]接收73处无宽度限制的%s；输入字符串可超过15字符并越界写。'),
(D,'tc.c:133的cmd_name[16]接收135处无宽度限制的scanf %s，可被长输入越界写。'),
(D,'telemetry.c:15声明s_hk_table[8]，30写索引8，超过0—7。'),
(D,'telemetry.c:15声明s_hk_table[8]，88读索引8，超过0—7。'),
(D,'telemetry.c:99声明name[8]，102复制OBDH_HK_TM连同NUL需要11字节。'),
(D,'telemetry.c:99声明name[8]，104复制OBDH_AUX连同NUL需要9字节。'),
],
'ttc':[
(D,'auth.c:63声明source[8]，13定义AUTH_TAG_LEN为16，80从source复制16字节，源越界读。'),
(B,'auth.c:46的sizeof(s_replay_head++)不执行标量自增；保留sizeof副作用表达式提示，不据此声称重放头已更新。'),
(D,'fec.c:15声明s_exp[512]，43写索引512，超过0—511。'),
(D,'fec.c:66声明snapshot[16]，89复制48字节，源越界读。'),
(B,'fec.c:124的block只用于129的空指针判断，函数内没有通过block写入，可加const；该建议不评价解码算法是否完整。'),
(D,'fec.c:104对32位1u左移40位，移位数超过类型宽度。'),
(D,'tc_decode.c:131的name[8]为局部数组，145返回&name[0]，返回后生命周期结束；131和145属于同一个根因。'),
(D,'tc_decode.c:26声明s_opcode_table[16]，38写索引16，超过0—15。'),
(D,'tc_decode.c:50声明snapshot[24]，70复制48字节，源越界读。'),
(D,'tc_decode.c的cmd_name容量12字节，72复制TC_CMD_SET_MODE连同NUL需要16字节。'),
(D,'tc_decode.c:153声明opname[16]，161的sscanf %s没有宽度限制，长输入可导致目标越界。'),
(B,'tc_decode.c:151的name仅用于空判断、解析与输出，没有写入其指向对象，const建议成立；其他格式串风险单独审查。'),
]}
shared_app=(S,'Command.payload容量64，app.c:103局部条件只限制length<80。但完整程序唯一queue_push调用位于packet.c:53，必须先通过packet_decode。原始版length>64在packet.c:20首先触发B01越界写；修复B01后length≤64的不变量沿队列传递到app_dispatch。此处是B01下游风险位置，新增独立根因0。参考版仍报警属于跨函数队列不变量未建模；直接注入非法Command能破坏前置条件，但现有程序无该入口。边界探针在首个不安全拷贝前停止，没有以未定义行为之后的执行证明dispatch可达。')
shared_number=(B,'main.c:14的strtoul返回unsigned long，在当前Windows目标为32位，15的value>UINT32_MAX确实恒假；同一条件已检查errno和尾字符，溢出由ERANGE拒绝，且该比较在64位long平台有用，保留平台相关提示，不算解析缺陷。')
shared_const=(B,'storage.c:45的Platform指针仅用于读取flash；50起使用const uint8_t*读取记录并写出event，没有写Platform，可加const。')
reviews['01_earth_observer']=[shared_app,
    (D,'attitude.c:6使用index>ARRAY_LEN(m->wheel)而非>=；wheel容量3，index=3可到达9的越界写。'),
    (D,'mission.h声明tile[128]，camera.c:15只拒绝count>256，18允许129—256字节写入128字节目标。'),shared_number,shared_const]
reviews['02_deep_space_probe']=[shared_app,shared_number,
    (D,'mission.h声明steps[8]，sequencer.c:6只拒绝count>12，9复制count个SequenceStep，9—12个元素超过目标容量。'),shared_const]
reviews['03_lunar_lander']=[shared_app,shared_number,
    (D,'propulsion.c:4—8的ld_debit_fuel无余额判断且总返回true，40处的失败分支永不进入；41—43的燃料不足停机保护失效，与已登记L03燃料扣减缺陷同根。'),shared_const]
reviews['04_orbital_servicer']=[shared_app,shared_number,
    (B,'robot_arm.c:43的Waypoint指针w只读取joints和duration_ms，45—47没有通过w写入，可加const。'),shared_const]

rows={};raw=[]
for project in data:
    name=project['project'];root=roots[name]
    assert len(reviews[name])==len(project['diagnostics'])
    for index,(alert,(status,reason)) in enumerate(zip(project['diagnostics'],reviews[name])):
        location=alert['locations'][0];file='src/'+Path(location['file']).name;line=int(location['line'])
        path=root/file;source=path.read_text(encoding='utf-8').splitlines();assert 0<line<=len(source)
        item=dict(project=name,rule='cppcheck:'+alert['id'],file=file,line=line,status=status,reason=reason,
            source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),verification='source_review_not_hardware_execution',
            evidence=[dict(file=file,line=i+1,code=source[i]) for i in range(max(0,line-10),min(len(source),line+6))],
            raw_indices=[index],messages=[alert['msg']],trace_locations=alert['locations'])
        if status==S:
            item.update(registered_root=name+'-B01',independent_new_defect=False,
                root_cause_evidence='../detection/app_copy_chain/conclusion.json',
                reference_variant_classification='CONFIRMED_FP_UNDER_COMPLETE_PROGRAM_INGRESS_INVARIANT',
                verification='source_call_graph_and_stop_before_unsafe_copy_probes')
        identity=(name,item['rule'],file,line)
        raw.append(item.copy())
        if identity in rows:
            existing=rows[identity];assert existing['status']==status
            existing['raw_indices'].append(index);existing['messages'].append(alert['msg']);existing['trace_locations'].extend(alert['locations'])
        else:rows[identity]=item
rows=list(rows.values());counts=collections.Counter(r['status'] for r in rows)
assert len(raw)==68 and len(rows)==67
summary=dict(raw_diagnostics=68,deduplicated_rule_file_line=67,
    counts={s:counts.get(s,0) for s in [D,S,B,F,R]},
    by_project={p:dict(collections.Counter(r['status'] for r in rows if r['project']==p)) for p in roots},
    direct_defect_alerts=counts[D],downstream_duplicate_risk_locations=counts[S],downstream_new_independent_roots=0,
    defect_alert_share=counts[D]/len(rows),valid_direct_alert_share=(counts[D]+counts[B])/len(rows),
    direct_defect_share_excluding_downstream_locations=counts[D]/(len(rows)-counts[S]),
    valid_direct_alert_share_excluding_downstream_locations=(counts[D]+counts[B])/(len(rows)-counts[S]),
    distinct_defect_roots_are_not_equivalent_to_rule_file_line_count=True,
    interpretation='36 direct source-defect alerts, 4 B01 downstream duplicate-risk sites, 25 valid rule notices, and 2 false positives. The 36 direct alerts are not necessarily distinct defect roots. Four app.c:104 sites add no independent roots and are excluded from direct-alert share denominators where explicitly named. Source-reviewed outputs of this run only; no recall denominator or overall hardware accuracy. Multi-location trace points are not extra alerts; payload.c:96 source/destination diagnostics are merged. Probes stop BEFORE unsafe copy, so no post-UB dispatch execution is claimed. Reference app.c:104 findings are false positives under the complete program ingress invariant.',
    input_sha256=hashlib.sha256((OUT/'results.json').read_bytes()).hexdigest())
for name,value in [('review',rows),('review_summary',summary)]:
    (OUT/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
with (OUT/'review.csv').open('w',encoding='utf-8-sig',newline='') as f:
    fields=['project','rule','file','line','status','reason','registered_root','independent_new_defect','reference_variant_classification','root_cause_evidence','source_sha256','verification','raw_indices']
    writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,ensure_ascii=False,indent=2))
