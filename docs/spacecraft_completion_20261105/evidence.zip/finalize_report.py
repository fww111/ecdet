"""Freeze the report only after the final full-suite receipt has passed."""
import ast
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

out = Path(__file__).resolve().parent
report = out / '航天器嵌入式软件_完整测试报告_20261105.md'
summary = json.loads((out / 'review/summary.json').read_text(encoding='utf-8'))
tests = summary['full_suite']
assert tests['failed'] == 0 and tests['receipt']['source_unchanged']
assert tests['receipt']['returncode'] == 0
xml = ET.parse(out / 'full_verified/full_suite.xml').getroot()
suite = next(xml.iter('testsuite'))
seconds = float(suite.get('time', '0'))
text = report.read_text(encoding='utf-8')
text = text.replace(
    '日期：2026年11月5日。状态：**DRAFT——工程扫描与历史误报复核已完成，最终全量测试数值待回填。**',
    '日期：2026年11月5日。状态：本地复验完成，报告与证据已冻结。')
text = text.replace(
    '**待回填：**最终全量测试`full_verified`的通过、失败、跳过及源码一致性；测试收集结果为858个节点，实际执行尚未完成。',
    f"完整回归实际执行{tests['total']}项，{tests['passed']}项通过、{tests['failed']}项失败、{tests['skipped']}项跳过，耗时{seconds / 60:.1f}分钟。执行前后检测实现与测试源码哈希一致。")
text = text.replace(
    '|完整测试套件|最终验证仍在执行|**待回填full_verified最终通过/失败/跳过数及源码一致性**|',
    f"|完整测试套件|调试阶段发现并修复Z3访问异常与ESBMC超时类型错误|最终{tests['passed']}项通过、{tests['failed']}项失败、{tests['skipped']}项跳过；源码哈希一致|")
text = text.replace(
    '最终全量结果以`full_verified/full_suite.xml`和对应源码快照为准。',
    '最终全量结果见[JUnit回执](C:/Users/admin/Desktop/嵌入式项目/spacecraft_completion_20261105/full_verified/full_suite.xml)与[源码一致性回执](C:/Users/admin/Desktop/嵌入式项目/spacecraft_completion_20261105/full_verified/receipt.json)。网页扫描、定向修复和补丁落盘重扫已包含在回归中；这些流程测试不等于真实LLM补丁质量评估。')
text = text.replace(
    '当前完整报告以本地证据为交付。GitHub Actions工作流已准备，远端CI尚未执行；本轮不提交、不推送、不更新PR。待最终全量测试回执填入后，再冻结报告版本。',
    '本地代码、完整报告与测试证据已整理完成。GitHub Actions工作流已准备，远端CI尚未执行。本轮变更保留在本地，未提交、推送或更新PR。')
assert 'DRAFT' not in text and '待回填' not in text
report.write_text(text, encoding='utf-8')

without_fences = re.sub(r'```.*?```', '', text, flags=re.S)
links = re.findall(r'\]\((C:/[^)]+)\)', without_fences)
missing = [p for p in links if not Path(p).exists()]
assert not missing, missing
plain = re.sub(r'`[^`]*`', '', without_fences)
plain = re.sub(r'\]\([^)]*\)', ']', plain)
spacing = re.findall(r'[\u4e00-\u9fff]+ +[A-Za-z]+|[A-Za-z]+ +[\u4e00-\u9fff]+', plain)
assert not spacing, spacing
blocks = re.findall(r'```python\n(.*?)```', text, flags=re.S)
for block in blocks:
    ast.parse(block)
record = {
    'report': str(report),
    'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(),
    'frozen': True,
    'full_suite': {k: tests[k] for k in ['total', 'passed', 'failed', 'skipped']},
    'full_suite_seconds': seconds,
    'source_unchanged': True,
    'local_links_checked': len(links),
    'missing_links': missing,
    'chinese_english_spacing_issues': spacing,
    'python_blocks_parsed': len(blocks),
    'manual_sentence_review': {
        'completed': False,
        'scope': 'Final statistics, rule-expectation comparison, O03 contract scope, LLM units and delivery paragraphs',
        'prior_full_draft_review': 'detection_report_review.json',
    },
    'command_issue_record': [
        {
            'command': 'rg tests/test_llm_repair_verification.py scripts/validate_llm_endpoint.py',
            'result': 'The guessed test filename did not exist; available tests were inspected directly. No product execution failed in this lookup.',
        }
    ],
}
(out / 'work_record/final_report_review.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(record, ensure_ascii=False, indent=2))
