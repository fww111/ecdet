"""At most two diagnostic requests with the unchanged production request schema."""
import hashlib
import json
from pathlib import Path
import sys
import time
import urllib.request

WORKSPACE=Path(__file__).resolve().parents[3]
REPO=WORKSPACE/'ecdet';OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(REPO));sys.path.insert(0,str(REPO/'scripts'))
from validate_llm_endpoint import load_configuration,_redact,_endpoint
from ecdet.l2_ir.model import Alert,Location,Severity
from ecdet.l4_llm.triage import SYSTEM_PROMPT,_build_user_prompt,load_project_context,parse_verdict_json
from ecdet.l4_llm.slicer import slice_context

def main():
    baseline=json.loads((OUT/'validation.json').read_text(encoding='utf-8'))
    assert baseline['status']=='COMPLETED'
    remaining=min(2,32-baseline['budget']['calls'])
    config=load_configuration(settings_db=WORKSPACE/'ecdet本地检查/next_round_20261103/webui_data/ecdet_web.db')
    cases=[('O01','examples/spacecraft_local/04_orbital_servicer','src/robot_arm.c',10,'CERT C ARR30-C','机械臂关节索引可能超过数组边界'),
           ('FP-AOCS','examples/spacecraft/aocs','src/main.c',31,'MISRA C:2012 8.7','函数SysTick_Handler仅在本翻译单元中使用，建议限制为static')]
    records=[]
    for identifier,project,path,line,rule,message in cases[:remaining]:
        alert=Alert(rule,'diagnostic',Severity.WARNING,message,Location(path,line))
        context=load_project_context(REPO/project);slice_=slice_context(alert,context,16000)
        prompt=_build_user_prompt(alert,slice_,'',False)
        payload=json.dumps({'model':config.model,'messages':[{'role':'system','content':SYSTEM_PROMPT},{'role':'user','content':prompt}],'temperature':0.1}).encode('utf-8')
        request=urllib.request.Request(config.base_url+'/chat/completions',data=payload,headers={'Content-Type':'application/json','Authorization':'Bearer '+config.api_key})
        started=time.monotonic();record=dict(id=identifier,prompt_sha256=hashlib.sha256(prompt.encode('utf-8')).hexdigest())
        try:
            with urllib.request.urlopen(request,timeout=60) as response:body=json.loads(response.read().decode('utf-8'))
            choice=body.get('choices',[{}])[0];msg=choice.get('message',{});raw=msg.get('content')
            record.update(transport='PASS',response_model=body.get('model'),finish_reason=choice.get('finish_reason'),message_keys=list(msg),
                          raw_content=raw,content_type=type(raw).__name__,content_length=len(raw) if isinstance(raw,str) else None,
                          reasoning_length=len(msg.get('reasoning_content','') or ''),usage=body.get('usage'),
                          strict_parser_pass=parse_verdict_json(raw) is not None)
            if raw is None:record['format_issue']='message.content is missing or null'
            elif not isinstance(raw,str):record['format_issue']='message.content is not a string'
            elif not raw.strip():record['format_issue']='message.content is empty'
            else:
                try:
                    value=json.loads(raw);record['json_top_type']=type(value).__name__
                    record['json_field_types']={k:type(v).__name__ for k,v in value.items()} if isinstance(value,dict) else None
                    record['format_issue']='none' if record['strict_parser_pass'] else 'JSON parsed but required fields or values are invalid'
                except ValueError:record['format_issue']='content is not a standalone JSON document'
        except Exception as exc:record.update(transport='ERROR',error_type=type(exc).__name__)
        record['seconds']=round(time.monotonic()-started,3);records.append(record)
        (OUT/'response_diagnostics.json').write_text(json.dumps(_redact(dict(model=config.model,endpoint=_endpoint(config.base_url),baseline_calls=baseline['budget']['calls'],diagnostic_calls=len(records),total_calls=baseline['budget']['calls']+len(records),records=records),[config.api_key]),ensure_ascii=False,indent=2),encoding='utf-8')
        print(identifier,record['transport'],record.get('format_issue','transport error'),flush=True)

if __name__=='__main__':main()
