"""Real endpoint evaluation on 8 projects and 16 independently labelled alerts."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
import hashlib
import json
from pathlib import Path
import sys
import time

WORKSPACE=Path(__file__).resolve().parents[3]
REPO=WORKSPACE/'ecdet'
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(REPO));sys.path.insert(0,str(REPO/'scripts'))
from validate_llm_endpoint import load_configuration,_endpoint,_redact
from ecdet.l2_ir.model import Alert,Location,Provenance,Severity
from ecdet.l3_analysis.engine import AnalysisTarget,BuiltinEngine,collect_sources
from ecdet.l4_llm.triage import TriageRunner,load_project_context
from ecdet.l4_llm.client import OpenAICompatClient
from ecdet.l4_llm.budget import LlmCallBudget,BudgetedClient

def read(path):return json.loads(path.read_text(encoding='utf-8'))

def main():
    config=load_configuration(settings_db=WORKSPACE/'ecdet本地检查/next_round_20261103/webui_data/ecdet_web.db')
    assert config.base_url and config.model and config.api_key,'Configured real endpoint required'
    manifest=read(REPO/'examples/spacecraft_suite/manifest.json')
    contexts={};roots={};source_hashes={};current={}
    for project in manifest['projects']:
        name=project['name'];root=REPO/project['path'];roots[name]=root
        files=collect_sources(root);contexts[name]=load_project_context(root)
        source_hashes[name]={p.as_posix():hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
        engine=BuiltinEngine()
        current[name]=engine.run(AnalysisTarget(root,files,svd_path=root/'SPC3000.svd' if (root/'SPC3000.svd').exists() else None),{m.rule_id for m in engine.rules()})
    selections=['01_earth_observer-E01','02_deep_space_probe-D01','03_lunar_lander-L01','04_orbital_servicer-O01','REMOTE-01','REMOTE-04','REMOTE-09','R-EPS-01']
    jobs=[]
    for identifier in selections:
        case=next(c for c in manifest['defects'] if c['id']==identifier)
        matches=[a for a in current[case['project']] if a.rule_id==case['rule'] and a.location.path==case['file'] and a.location.line==case['line']]
        if identifier=='R-EPS-01':
            prior=read(WORKSPACE/'spacecraft_followup_20261104/scans/remote_final/eps/results.sarif')['runs'][0]['results']
            original=next(a for a in prior if a['ruleId']=='ECDET-BUSINESS-CONTRACT')
            matches=[Alert(case['rule'],'business-contract',Severity.ERROR,original['message']['text'],Location(case['file'],case['line']),provenance=Provenance.DETECTED)]
        assert matches,identifier
        jobs.append(dict(id='TP-'+identifier,project=case['project'],expected='TRUE_POSITIVE',truth_origin='examples/spacecraft_suite/manifest.json',alert=matches[0]))
    historical=read(WORKSPACE/'spacecraft_fix_20261104/review/all_alerts.json')
    review=read(REPO/'docs/spacecraft_verification_20261105/review29.json')
    for row in review:
        if row['status']!='CONFIRMED_FP':continue
        old=next(a for a in historical if a['project']==row['project'] and a['rule']==row['rule'] and a['file']==row['file'] and a['line']==row['line'])
        alert=Alert(row['rule'],'historical-candidate',Severity.NOTE,old['message'],Location(row['file'],row['line']),provenance=Provenance.SUSPECTED)
        jobs.append(dict(id='FP-'+row['project'],project=row['project'],expected='FALSE_POSITIVE',truth_origin='review29:'+row['id'],alert=alert))
    selected={'aocs':'g_sys_tick','eps':'g_adc_ticks','obdh':'g_hk_tick','ttc':'g_frame_ticks'}
    for project,symbol in selected.items():
        row=next(r for r in review if r['project']==project and r['symbol']==symbol and r['status']=='HARDWARE_CONDITIONAL')
        alert=next(a for a in current[project] if a.rule_id==row['rule'] and a.location.path==row['file'] and a.location.line==row['line'])
        jobs.append(dict(id='HW-'+project,project=project,expected='NEEDS_REVIEW',truth_origin='review29:'+row['id'],alert=alert))
    assert len(jobs)==16
    budget=LlmCallBudget(32)
    raw=OpenAICompatClient(config.base_url,config.model,config.api_key,timeout=60)
    records=[]
    def execute(job):
        runner=TriageRunner(BudgetedClient(raw,budget,job['id']),budget_chars=16000)
        start=time.monotonic();verdict=runner.triage(job['alert'],contexts[job['project']])
        structured=any(a['status']=='PASS' for a in verdict.attempts)
        suggestion=verdict.suggested_verdict if structured else None
        return dict(id=job['id'],project=job['project'],expected_verdict=job['expected'],truth_origin=job['truth_origin'],
                    rule=job['alert'].rule_id,file=job['alert'].location.path,line=job['alert'].location.line,
                    original_severity=job['alert'].severity.value,seconds=round(time.monotonic()-start,3),
                    calls=verdict.llm_calls,structured=structured,
                    raw_suggestion=suggestion,raw_suggestion_match=(suggestion==job['expected']) if structured else None,
                    final_verdict=verdict.verdict,citation_verified=verdict.verified,
                    final_suggestion_match=(verdict.verdict==job['expected']) if structured else None,
                    triage=verdict.to_alert_props())
    def save():
        snapshot=budget.snapshot()
        result=dict(mode='real',model=config.model,endpoint=_endpoint(config.base_url),credential_source=config.credential_source,
            status='COMPLETED' if len(records)==len(jobs) else 'RUNNING',budget=snapshot,
            summary=dict(projects=len(roots),cases=len(records),planned_cases=16,transport_successes=sum(a['status']=='PASS' for a in snapshot['attempts']),
                         structured=sum(r['structured'] for r in records),raw_suggestion_matches=sum(r['raw_suggestion_match'] is True for r in records),
                         citation_verified=sum(r['citation_verified'] for r in records),final_verdicts={v:sum(r['final_verdict']==v for r in records) for v in ['TRUE_POSITIVE','FALSE_POSITIVE','NEEDS_REVIEW']}),
            cases=sorted(records,key=lambda r:r['id']),source_sha256=source_hashes,
            interpretation='16 selected alerts from 8 projects; full project sources loaded but bounded slices sent. Citation validation is not semantic proof. FP entries replay historical removed alerts. No population accuracy claim.')
        (OUT/'validation.json').write_text(json.dumps(_redact(result,[config.api_key]),ensure_ascii=False,indent=2),encoding='utf-8')
        return result
    save()
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures=[executor.submit(execute,job) for job in jobs]
        for future in as_completed(futures):
            record=future.result();records.append(record);save()
            print(record['id'],record['final_verdict'],'structured='+str(record['structured']),flush=True)
    assert all(hashlib.sha256((roots[name]/p).read_bytes()).hexdigest()==h for name,files in source_hashes.items() for p,h in files.items())
    result=save();print(json.dumps(result['summary'],ensure_ascii=False),flush=True)

if __name__=='__main__':main()
