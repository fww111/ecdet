#include <stdint.h>
#include "limits.h"
int bad(int n){int a[CAPACITY]={0};if(n<CAPACITY)return a[n];return 0;}
int good(int n){int a[CAPACITY]={0};if(n>=0 && n<CAPACITY)return a[n];return 0;}
