from pathlib import Path
import json,collections,time,sys
WORK=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(WORK/'ecdet'))
from ecdet.advanced_cli import analyze_constraint_files
out=Path(__file__).parent/'engineering_final';out.mkdir(exist_ok=True)
rows=[]
for group,base in [('local',WORK/'spacecraft_samples_20261104/projects'),('remote',WORK/'ecdet_spacecraft_remote_20261104/examples/spacecraft')]:
    for root in sorted(base.iterdir()):
        if not root.is_dir():continue
        files=[p.relative_to(root) for p in sorted((root/'src').glob('*.c'))]
        if not files:continue
        start=time.monotonic();report,alerts=analyze_constraint_files(root,files)
        (out/(group+'_'+root.name+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        reasons=collections.Counter(x['reason'] for f in report['files'] for x in f['results'] if x['status']=='UNSUPPORTED')
        row=dict(project=root.name,group=group,status_counts=report['status_counts'],alerts=len(alerts),preprocessed=sum(f.get('context',{}).get('preprocessing')=='complete' for f in report['files']),files=len(files),seconds=round(time.monotonic()-start,2),reasons=dict(reasons))
        rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
(out/'engineering_summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
