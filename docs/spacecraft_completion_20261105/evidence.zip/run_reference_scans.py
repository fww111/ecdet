"""Serial final scans of five full repaired controls under the qualified tools."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
OUT=Path(__file__).resolve().parent
WORK=OUT.parent
REPO=WORK/'ecdet'
sys.path.insert(0,str(OUT/'tooling'))
from environment import environment
env=environment(ctu=True);env['ECDET_ESBMC_TIMEOUT']='30'
destination=OUT/'reference_scans_final';destination.mkdir(exist_ok=True)
detector={p.relative_to(REPO).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (REPO/'ecdet').rglob('*.py')}
(destination/'detector_hashes.json').write_text(json.dumps(detector,indent=2),encoding='utf-8')
rows=[]
for prep in json.loads((OUT/'controls/preparation.json').read_text(encoding='utf-8')):
    name=prep['project'];root=OUT/'controls'/name;out=destination/name
    out.mkdir(exist_ok=True)
    if (out/'receipt.json').exists():raise ValueError('Completed reference receipt already exists: '+name)
    before={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in prep['reference_source_sha256']}
    assert before==prep['reference_source_sha256']
    command=[sys.executable,'-m','ecdet','scan',str(root),'--no-build','--profile','industrial','--constraints',
             '--contracts',str(REPO/'examples/business_contracts/contracts'/name/'contracts.json'),
             '--contract-compiler','C:/mingw64/bin/gcc.exe','-o',str(out)]
    print('START',name,flush=True);started=time.monotonic()
    with (out/'scan.log').open('w',encoding='utf-8') as f:
        run=subprocess.run(command,cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT)
    native=json.loads((out/'codechecker/latest.json').read_text(encoding='utf-8'))
    contracts=json.loads((out/'business-contracts/contracts.json').read_text(encoding='utf-8'))
    z3=json.loads((out/'constraints.json').read_text(encoding='utf-8'))
    esbmc=json.loads((out/'esbmc/receipt.json').read_text(encoding='utf-8'))
    alerts=json.loads((out/'results.sarif').read_text(encoding='utf-8'))['runs'][0]['results']
    after={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in before}
    row=dict(project=name,command=command,returncode=run.returncode,seconds=round(time.monotonic()-started,2),
        source_sha256=before,sources_unchanged=before==after,codechecker=native['status'],analyzers=native.get('analyzers'),
        ctu=native.get('ctu'),contracts=contracts['status_counts'],z3=z3['status_counts'],esbmc=esbmc['status'],raw_alerts=len(alerts))
    (out/'receipt.json').write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
    rows.append(row);print('END',name,json.dumps({k:row[k] for k in ['returncode','codechecker','ctu','contracts','z3','esbmc','raw_alerts']}),flush=True)
    assert native['status']=='complete' and row['sources_unchanged']
    assert set(contracts['status_counts'])=={'PASS'},contracts['status_counts']
assert all(hashlib.sha256((REPO/n).read_bytes()).hexdigest()==h for n,h in detector.items()),'Detector changed during final reference scans'
(destination/'summary.json').write_text(json.dumps(dict(scope='Five repaired full-project controls; contract PASS is separate from solver completeness',projects=rows,detector_hashes_match=True),ensure_ascii=False,indent=2),encoding='utf-8')
print('FINAL_REFERENCE_SCANS_COMPLETE',flush=True)
