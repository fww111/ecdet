"""Produce evidence-bound final statistics from completed native runs."""
import collections,csv,hashlib,json,re,xml.etree.ElementTree as ET
from pathlib import Path
O=Path(__file__).resolve().parent;W=O.parent;R=W/'ecdet';D=O/'review';D.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(name,data):
 (D/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 if isinstance(data,list) and data:
  with (D/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
   wr=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for x in data for k in x)));wr.writeheader();wr.writerows(data)
main=read(O/'scans_ctu_final/summary.json');assert main['detected']==main['total']==44
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in main['detector_sha256'].items())
rows=[];scan_rows=[];z3=collections.Counter();bmc=collections.Counter();contracts=collections.Counter()
for group in ['scans_ctu_final','reference_scans_final']:
 for p in sorted((O/group).glob('*/receipt.json')):
  if not (p.parent/'results.sarif').exists():continue
  project=p.parent.name;data=read(p.parent/'results.sarif')['runs'][0]['results'];receipt=read(p)
  native=read(p.parent/'codechecker/latest.json');assert native['status']=='complete' and native['ctu'] is True
  assert {'clangsa','clang-tidy','cppcheck','gcc'}<=set(native['analyzers'])
  dedup=int(re.search(r'告警（去重后）：(\d+)',(p.parent/'scan.log').read_text(encoding='utf-8'))[1])
  zs=read(p.parent/'constraints.json')['status_counts'];bs=read(p.parent/'esbmc/receipt.json')['status']
  z3.update(zs);bmc.update([bs]);contract=p.parent/'business-contracts/contracts.json';cs=read(contract)['status_counts'] if contract.exists() else {}
  contracts.update(cs)
  if group=='reference_scans_final':assert set(cs)=={'PASS'}
  scan_rows.append(dict(group=group,project=project,raw=len(data),deduplicated=dedup,codechecker='complete',ctu=True,returncode=receipt['returncode'],z3=zs,esbmc=bs,contracts=cs))
  for a in data:
   loc=a['locations'][0]['physicalLocation'];props=a.get('properties',{})
   rows.append(dict(group=group,project=project,rule=a['ruleId'],file=loc['artifactLocation']['uri'],line=loc['region']['startLine'],engine=props.get('engine'),message=a['message']['text'],is_defect=props.get('analysis',{}).get('is_defect',True)))
assert len(scan_rows)==13 and contracts=={'FAIL':6,'PASS':6},(len(scan_rows),contracts)
keys={(a['project'],a['rule'],a['file'],a['line']) for a in rows if a['group']=='scans_ctu_final'}
previous=read(R/'docs/spacecraft_verification_20261105/resolved_false_positives.json')
retained=[r for r in previous if (r['project'],r['rule'],r['file'],r['line']) in keys]
save('retained_historical_false_positives',retained)
assert not retained,retained
doc=ET.parse(O/'full_verified/full_suite.xml').getroot();tests=list(doc.iter('testcase'))
fail=[dict(classname=c.get('classname'),name=c.get('name')) for c in tests if c.find('failure') is not None or c.find('error') is not None]
skipped=sum(c.find('skipped') is not None for c in tests)
full=read(O/'full_verified/receipt.json')
test_result=dict(total=len(tests),passed=len(tests)-len(fail)-skipped,failed=len(fail),skipped=skipped,failures=fail,receipt=full)
save('test_verification',test_result)
assert not fail and full['returncode']==0 and full['source_unchanged']
pairs=read(O/'business_pairs/pairs.json');assert collections.Counter(p['status'] for p in pairs)=={'FAIL':6,'PASS':6}
summary=dict(defect_roots=44,detected=44,static_roots=38,business_roots=6,scan_runs=13,
 original_raw=sum(r['raw'] for r in scan_rows if r['group']=='scans_ctu_final'),original_deduplicated=sum(r['deduplicated'] for r in scan_rows if r['group']=='scans_ctu_final'),
 historical_false_positives_checked=len(previous),historical_false_positives_retained=len(retained),
 z3_total=dict(z3),esbmc_statuses=dict(bmc),contract_statuses=dict(contracts),
 contract_reference_assertions=sum(p.get('assertions',0) for p in pairs),full_suite=test_result,
 cppcheck=read(O/'cppcheck/review_summary.json'),llm_controlled=read(O/'llm/controlled/validation.json')['summary'],llm_spacecraft=read(O/'llm/spacecraft/validation.json')['summary'],
 hardware_pending=7,remote_ci_executed=False,pr_updated=False)
for n,d in [('summary',summary),('scan_receipts',scan_rows),('all_alerts',rows),('defect_roots',main['defects'])]:save(n,d)
print(json.dumps({k:v for k,v in summary.items() if k not in ['cppcheck','full_suite','llm_controlled','llm_spacecraft']},ensure_ascii=False,indent=2))
