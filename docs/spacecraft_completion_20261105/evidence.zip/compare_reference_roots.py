"""Compare the same registered root and function in complete repaired controls."""
from pathlib import Path
import json,sys
OUT=Path(__file__).resolve().parent;REPO=OUT.parent/'ecdet'
sys.path.insert(0,str(REPO))
from ecdet.l3_analysis.builtin_rules.checks import build_file_facts
manifest=json.loads((REPO/'examples/spacecraft_suite/manifest.json').read_text(encoding='utf-8'))
projects={p['name']:p for p in manifest['projects']}
rows=[]
for case in manifest['defects']:
    reference=OUT/'controls'/case['project']
    if not reference.exists():continue
    original=REPO/projects[case['project']]['path']/case['file']
    original_facts=build_file_facts(case['file'],original.read_text(encoding='utf-8'))
    owner=[f for f in original_facts.functions if f.def_line<=case['line']<=f.body_close_line]
    assert len(owner)==1,case
    control_facts=build_file_facts(case['file'],(reference/case['file']).read_text(encoding='utf-8'))
    target=[f for f in control_facts.functions if f.name==owner[0].name]
    assert len(target)==1,case
    alerts=json.loads((OUT/'reference_scans_final'/case['project']/'results.sarif').read_text(encoding='utf-8'))['runs'][0]['results']
    remaining=[]
    for alert in alerts:
        loc=alert['locations'][0]['physicalLocation']
        if alert['ruleId']==case['rule'] and loc['artifactLocation']['uri']==case['file'] and target[0].def_line<=loc['region']['startLine']<=target[0].body_close_line:
            remaining.append(dict(rule=alert['ruleId'],line=loc['region']['startLine'],message=alert['message']['text']))
    rows.append(dict(id=case['id'],project=case['project'],file=case['file'],function=target[0].name,
                     expected_rule=case['rule'],control_function_start=target[0].def_line,control_function_end=target[0].body_close_line,
                     remaining_same_rule_in_target_function=remaining))
assert len(rows)==33
(OUT/'reference_scans_final/root_comparison.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
remaining=[r for r in rows if r['remaining_same_rule_in_target_function']]
print(json.dumps(dict(roots=len(rows),roots_without_prior_rule_in_target_function=len(rows)-len(remaining),remaining=remaining),ensure_ascii=False,indent=2))
