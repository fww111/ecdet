void __ESBMC_assert(_Bool,const char *);int main(void){int x=3;__ESBMC_assert(x<2,"upper bound");return 0;}
