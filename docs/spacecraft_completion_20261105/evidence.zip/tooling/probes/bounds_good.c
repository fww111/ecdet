int main(void){int a[2]={0,1};return a[1];}
