int get_value(void);int main(void){return 10/get_value();}
