#include "api.h"
void __ESBMC_assert(_Bool,const char*);int main(void){__ESBMC_assert(helper(1)==2,"cross file");return 0;}
