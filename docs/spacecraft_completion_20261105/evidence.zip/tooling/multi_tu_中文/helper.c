#include "api.h"
int helper(int value){return value+1;}
