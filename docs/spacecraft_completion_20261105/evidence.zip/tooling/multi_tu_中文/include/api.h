int helper(int value);
