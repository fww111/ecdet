import json,os
from pathlib import Path
def environment(ctu=False):
    data=json.loads((Path(__file__).parent/'environment.json').read_text(encoding='utf-8'))
    root=Path(__file__).resolve().parents[2]
    env=os.environ.copy()
    env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONPATH=str(root/'ecdet'),ECDET_ESBMC=data['esbmc'],ECDET_ESBMC_TIMEOUT=str(data['esbmc_timeout']))
    bins=[str(Path(data['python']).parent),str(Path(data['cppcheck']).parent),str(Path(data['esbmc']).parent),'C:/mingw64/bin',data['llvm']]
    if ctu:
        bins.insert(0,data['isolated_ctu_bin'])
        env['CC_ANALYZER_BIN']='clangsa:'+str(Path(data['isolated_ctu_bin'])/'clang.exe')+';clang-tidy:'+str(Path(data['llvm'])/'clang-tidy.exe')
    else:env.pop('CC_ANALYZER_BIN',None)
    env['PATH']=os.pathsep.join([*bins,env.get('PATH','')])
    return env
