from pathlib import Path
import json,os,sys,traceback
from environment import environment
os.environ.update(environment(ctu=False))
repo=Path(__file__).resolve().parents[2]/'ecdet';sys.path.insert(0,str(repo))
from ecdet.l3_analysis.engine import AnalysisTarget,CodeCheckerEngine,collect_sources
base=Path(__file__).parent/'ctu_probes_noctu';rows=[]
for name,value in [('bad',0)]:
 root=base/name;root.mkdir(parents=True,exist_ok=True)
 (root/'main.c').write_text('int get_value(void);int main(void){return 10/get_value();}\n')
 (root/'helper.c').write_text('int get_value(void){return '+str(value)+';}\n')
 db=[dict(directory=str(root.resolve()),file=str(p.resolve()),arguments=['C:/mingw64/bin/gcc.exe','-std=c11','-c',str(p.resolve())]) for p in root.glob('*.c')]
 (root/'compile_commands.json').write_text(json.dumps(db))
 engine=CodeCheckerEngine();target=AnalysisTarget(root.resolve(),collect_sources(root),artifact_dir=base/(name+'_reports'))
 try:
  alerts=engine.run(target,set());rows.append(dict(variant=name,status=engine.scan_manifest.get('status'),ctu=engine.scan_manifest.get('ctu'),alerts=[dict(rule=a.rule_id,file=a.location.path,line=a.location.line,message=a.message) for a in alerts],manifest=engine.scan_manifest))
 except Exception as exc:
  rows.append(dict(variant=name,error=str(exc),manifest=engine.scan_manifest));traceback.print_exc()
 (base/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8');print(name,rows[-1].get('status'),len(rows[-1].get('alerts',[])),flush=True)
