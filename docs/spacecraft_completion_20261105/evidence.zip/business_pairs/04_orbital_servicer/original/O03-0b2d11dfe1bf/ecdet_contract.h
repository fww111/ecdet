#ifndef ECDET_CONTRACT_H
#define ECDET_CONTRACT_H
#include <stdio.h>
static unsigned ecdet_contract_checks;
static void ecdet_contract_enter(void) {
    fprintf(stderr,"ECDET_TARGET:O03\n"); fflush(stderr);
}
#define ECDET_CHECK(x) do { ++ecdet_contract_checks; if (!(x)) {     fprintf(stderr,"ECDET_FAIL:O03:%u:%s\n",__LINE__,#x);     fflush(stderr); return 10; } } while (0)
#define ECDET_PASS() do { fprintf(stderr,"ECDET_PASS:O03:%u\n",     ecdet_contract_checks); fflush(stderr); return 0; } while (0)
#endif
